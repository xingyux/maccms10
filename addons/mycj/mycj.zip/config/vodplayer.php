<?php
return array (
  'mp4' => 
  array (
    'status' => '1',
    'from' => 'mp4',
    'show' => '高清MP4',
    'des' => '支持手机电脑在线播放',
    'ps' => '0',
    'parse' => '',
    'sort' => 1080,
    'tip' => '无需安装任何插件',
    'id' => 'mp4',
  ),
  'm3u8' => 
  array (
    'status' => '1',
    'from' => 'm3u8',
    'show' => '高清m3u8',
    'des' => '支持手机电脑在线播放',
    'ps' => '0',
    'parse' => '',
    'sort' => 1079,
    'tip' => '无需安装任何插件',
    'id' => 'm3u8',
  ),
);